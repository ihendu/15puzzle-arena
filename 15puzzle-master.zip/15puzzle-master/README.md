# 15Puzzle

15 puzzle game with react, typescript and styled-components.

I'm new to styled-components and Typescript, any PRs and suggestions are welcome and greatly appreciated.

[Play Game](https://15puzzle.aliemir.now.sh)
